import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { CarDto } from './models/car-dto';
import {HttpClient, HttpResponse, HttpParams} from '@angular/common/http'

@Injectable({
  providedIn: 'root'
})
export class MainService {

  counter: number = 0;

  constructor(private http: HttpClient) { }

  getCars(): Observable<Array<CarDto>> {
    return this.http.get<Array<CarDto>>('http://localhost:8081/api/cars/dto');
  }

}
