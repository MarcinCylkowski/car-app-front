import { MainService } from "./../main.service";
import { Component, OnInit } from "@angular/core";

@Component({
  selector: "app-home",
  templateUrl: "./home.component.html",
  styleUrls: ["./home.component.css"]
})
export class HomeComponent implements OnInit {
  greet: string = "Hello World!";
  date: Date = new Date();

  constructor(public mainService: MainService) {}

  ngOnInit() {
    this.getName("lukasz", 28);
  }

  getName(name: string, age?: number): string {
    return "moje imie to Lukasz";
  }

  incrementCounter() {
    this.mainService.counter += 1;
  }

  getCars() {
    this.mainService.getCars().subscribe(json => {
      console.log(json);
    })
  }
}
