export interface CarDto {
  brand: string,
  carType: string,
  describe: string,
  model: string,
  productionYear: string
}
